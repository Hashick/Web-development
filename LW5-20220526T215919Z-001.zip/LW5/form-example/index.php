<!DOCTYPE html>
<html lang="ru">
<head>
    <title>Пример обработки формы</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="styles/style.css" />
</head>

<body>
    <h1>Тут ваш сайт</h1>
    <hr/>

    <?php include "form.php" ?>

    <hr/>
    <h3>Тут вашему сайт конец:)</h3>
</body>